# Backlog

Review ve Verify adımlarında **SONRA** etiketi alan her bulgu buraya düşer.
Buraya düşmeyen bulgu kaybolmuş sayılır (`00-IS-HATTI.md` § 5).

Öncelik: **BLOK** (sürümü engeller) · **YÜKSEK** · **ORTA** · **DÜŞÜK**

---

## Planlı iş paketleri (v3 PLAN'ından)

| İP | Başlık | Kaynak | Öncelik | Durum |
|----|--------|--------|---------|-------|
| İP-01 | Mühendislik altyapısı | v3 SPEC E-1, E-2 | YÜKSEK | ✅ tamamlandı |
| İP-02 | Belge-kod tutarlılığı + sürümleme | v3 SPEC D-2, E-5 | YÜKSEK | ✅ tamamlandı |
| İP-03 | Eval hattı + G-11/G-12 baseline | v3 SPEC A-1, A-2, A-3 | BLOK | sırada |
| İP-04 | Test setini genişlet (80 + 30) | v3 SPEC A-5 | YÜKSEK | bekliyor |
| İP-05 | Regresyon kapısı | v3 SPEC A-4 | ORTA | bekliyor |
| İP-06 | G-16 kolon maskelemesi | v3 SPEC B-1 | BLOK | bekliyor |
| İP-07 | G-14 zaman aşımı + salt-okunurluk | v3 SPEC B-2, B-3 | BLOK | bekliyor |
| İP-08 | G-18 sertleştirme + kırmızı takım | v3 SPEC B-4 | YÜKSEK | bekliyor |
| İP-09 | G-17 hash zinciri + kimlik sertleştirme | v3 SPEC B-5, B-6 | YÜKSEK | bekliyor |
| İP-10 | Durum yalıtımı (bağlantı sızıntısı) | v3 SPEC C-1 | BLOK | bekliyor |
| İP-11 | FastAPI çekirdeği | v3 SPEC C-2 | ORTA | bekliyor |
| İP-12 | Docker Compose güncellemesi | v3 SPEC C-3 | DÜŞÜK | bekliyor |
| İP-13 | Çift lisans yapısı | v3 SPEC D-1 | ORTA | bekliyor |
| İP-14 | Kanıt dosyası | v3 SPEC E-5 | YÜKSEK | bekliyor |

---

## İP-01/02 sırasında ortaya çıkan yeni maddeler

| İP | Başlık | Kaynak | Öncelik |
|----|--------|--------|---------|
| **İP-15** | **Yapısal loglama + kapsam eşiği.** `app/generator.py` içinde API çağrısı başarısız olduğunda hata sessizce yutuluyor (`except Exception: pass`, iki yerde) ve yerel moda düşülüyor. Kullanıcı mod etiketini görüyor ama hatanın ne olduğunu hiç kimse görmüyor — saha teşhisi imkânsız. Ayrıca `pyproject.toml`'daki kapsam eşiği şu an yalnız raporlayıcı; zorlayıcı hale gelmeli. **v3 SPEC'te E-3 ve E-4 gereksinimlerinin sahibi bir İP yoktu — bu, planın kendi Review'unda çıkan bir boşluktur.** | Review İP-01 · ruff S110/B904 | YÜKSEK |
| **İP-16** | **Dashboard sorgularında tanımlayıcı birleştirme.** `ui/pages/1_Dashboard.py` ve `ui/streamlit_app.py` tablo adlarını f-string ile SQL'e gömüyor (5 nokta). Girdi kullanıcıdan değil şema keşfinden geliyor, dolayısıyla bugün istismar edilebilir değil — ama ürünün kendi ilkesi bu kalıbı yasaklıyor ve kullanıcı tanımlı şemalarda tablo adı artık güvenilir bir kaynak değildir. Tanımlayıcılar sqlglot ile alıntılanmalı. | Review İP-01 · ruff S608 | ORTA |
| **İP-17** | **`ruff format` kararı.** Depo şu an biçimlendirilmemiş; `ruff format` 24 dosyayı değiştirir. İP-01'de bilinçli olarak **yapılmadı**: Faz 2'yi İhsan yazacak ve büyük bir biçim diff'i o çalışmanın üzerine gelirse gözden geçirmeyi zorlaştırır. Faz 2 bittikten sonra tek seferde uygulanmalı ve CI'a eklenmeli. | Review İP-01 | DÜŞÜK |
| **İP-18** | **pandas 3.x uyumluluğu.** Bağımlılık kilidi oluşturulurken pandas bilinçli olarak `<3` ile sınırlandı; en yeni çözümleme 3.0.5 getiriyordu ve dashboard kodunun bu sürümle uyumu denenmedi. Sınır kaldırılmadan önce arayüz akışları 3.x altında koşulmalı. | Verify İP-01 | DÜŞÜK |

---

## Kapsam dışı bırakılanlar (v3 SPEC § 5 — unutulmasın diye burada)

| Konu | Ne zaman yeniden açılır |
|------|-------------------------|
| QLoRA fine-tune | İP-03 baseline'ı %80'in altında çıkarsa (ADR-2) |
| G-04 doğal dil özeti | v3.1 |
| G-08 sorgu geçmişi + tekrar önerisi | v3.1 |
| Doğal dil ile dashboard filtreleme | v3.1 |
| Zamanlanmış PDF / e-posta raporu | v3.1 |
| Çok kiracılı SaaS | Kurumsal katman (İP-13 sonrası) |
| React yeniden yazımı | İP-11 sonrası, talep gelirse |

---

## Kapanan maddeler

| Madde | Sonuç |
|-------|-------|
| `.streamlit/config.toml` sır barındırıyor mu? | **Hayır.** Yalnızca `fileWatcherType = "none"` ve `gatherUsageStats = false`. Verify sırasında okundu, temiz. |
| `.dockerignore` var olmayan `training/output/` yolunu listeliyordu | Kaldırıldı; `.github/` ve `.pytest_cache/` eklendi (İP-02). |
