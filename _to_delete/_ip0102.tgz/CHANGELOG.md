# Değişiklik Günlüğü

Bu dosyanın biçimi [Keep a Changelog](https://keepachangelog.com/tr/1.1.0/) esaslıdır ve
sürümleme [Semantic Versioning](https://semver.org/lang/tr/) izler.

Her sürüm, iş hattının Ship kapısından (`docs/is-hatti/00-IS-HATTI.md` § 9) geçerek çıkar.

---

## [Yayınlanmamış]

### Eklendi
- `pyproject.toml`: proje metaverisi, ruff yapılandırması, pytest ve kapsam ayarları
- Katmanlı ve **pinlenmiş** bağımlılıklar (`requirements/`): `core` · `rag` · `ui` · `dev` · `drivers`.
  Tek sürüm kaynağı `all.txt`; katmanlar ona kısıtlanır, çelişen pin oluşamaz.
  Aynı commit iki kez kurulduğunda aynı sürümler gelir.
- GitHub Actions CI: ruff → pytest (Python 3.10/3.11/3.13) → `--gold-only` eval → Docker derlemesi.
  Hiçbir adım gerçek bir LLM servisi gerektirmez.
- `docs/is-hatti/`: iş hattı operasyon modeli, v3 SPEC ve PLAN, backlog

### Değiştirildi
- İçe aktarım sırası, kullanılmayan içe aktarımlar ve belirsiz değişken adları düzeltildi
  (ruff otomatik düzeltmesi + elle; **davranış değişikliği yok**)
- `app/schema_rag.py`: koleksiyon adı üreten MD5 çağrısı `usedforsecurity=False` ile
  işaretlendi — güvenlik amaçlı olmadığı artık kodda yazıyor
- `Dockerfile`: pinlenmiş kilit dosyalarını kullanıyor

### Düzeltildi (belge)
- **README'nin "QLoRA fine-tune" bölümü kaldırıldı.** Anlattığı `training/` klasörü ve
  içindeki iki script depoda hiç bulunmuyordu. Klasör yapısı listesinden de çıkarıldı.
  QLoRA kararı ADR-2'ye bağlıdır ve baseline ölçümü (İP-03) sonrası yeniden açılacaktır.
- **Karşılığı olmayan güvenlik iddiaları işaretlendi.** README, kişisel veri işaretli
  kolonların maskelendiğini (G-16) ve denetim izinin değiştirilemez olduğunu (G-17)
  söylüyordu; ikisi de kodda uygulanmamıştı. İlgili satırlar, gerçekte ne olduğunu
  söyleyecek biçimde düzeltildi ve hangi iş paketinin kapatacağı yazıldı.
- Test sayısı düzeltildi: belgelerde 75 yazıyordu, gerçek sayı 88.

### Bilinen açıklar (kapatılmadı — kayıt altına alındı)
Ayrıntı için `docs/is-hatti/BACKLOG.md`:
- G-16 kolon maskelemesi uygulanmıyor (İP-06)
- Sorgu zaman aşımı ve salt-okunurluk yalnız SQLite'ta zorlanıyor (İP-07)
- Bağlantı değişikliği süreç genelinde etkili — çok kullanıcılıda veritabanı sızıntısı (İP-10)
- Execution accuracy (G-11) hiç ölçülmedi (İP-03)

---

## [2.3.0] — 2026-07-25

### Eklendi
- Kimlik doğrulama: giriş kapısı, ilk kurulum sihirbazı, PBKDF2-SHA256 şifre saklama,
  `yonetici` / `analist` rolleri, kullanıcı yönetimi sayfası
- Denetim izi artık oturum açan gerçek kimliğe bağlı
- `Dockerfile` + `docker-compose.yml`: tek komutla uygulama + Ollama, kalıcı veriler named volume'da

## [2.2.0] — 2026-07-25

### Eklendi
- Bağlantı Yöneticisi: SQLite / PostgreSQL / MySQL / SQL Server arayüzden seçilebiliyor,
  bağlantı testi, şifresiz profil kaydetme
- Bağlantı değişince RAG indeksi yeniden kuruluyor; Chroma koleksiyonu bağlantıya bağlı adlandırılıyor
- İkinci demo şema: `demo/seed_satis.py`

## [2.1.0] — 2026-07-25

### Eklendi
- Hizmet Analizi dashboard'u: filtre şeridi, KPI şeridi, bölüm bazlı grafik,
  bölüm × ay ısı haritası, doktor özet tablosu
- Her görselin altında "SQL göster" (G-02 dashboard'a taşındı)
- Yönetici Önerisi: KPI özeti yerel LLM'e gider, LLM yoksa kural tabanlı eşik önerileri

### Değiştirildi
- Isı haritasından matplotlib bağımlılığı kaldırıldı
- LLM hataları için anlaşılır mesajlar (Ollama kapalı, zaman aşımı, HTTP hatası)

## [1.0.0] — 2026-07-25

İlk sürüm. Sistem analizi dosyasındaki MVP uygulama sırasının 1–9. adımları.

### Eklendi
- Uçtan uca pipeline: ön işleme (G-07/09) → RAG bağlamı (G-05/06) → üretim (G-01) →
  doğrulama (G-10/18) → salt-okunur yürütme (G-14) → denetim izi (G-17)
- Türkçe göreli tarih çözümleme, hafif kök indirgeme
- sqlglot tabanlı doğrulama: SELECT-only, tablo ve kolon halüsinasyonu yakalama, lehçe çevirisi
- Streamlit arayüzü: SQL her zaman görünür, sonuç grafiği, CSV indirme, şema tarayıcı
- 50 soruluk Türkçe test seti + execution accuracy koşucusu + `--gold-only` bütünlük modu
- Demo hastane şeması ve sentetik veri üreteci

[Yayınlanmamış]: https://github.com/Arvas65/sorbi/compare/v2.3.0...HEAD
[2.3.0]: https://github.com/Arvas65/sorbi/compare/v2.2.0...v2.3.0
[2.2.0]: https://github.com/Arvas65/sorbi/compare/v2.1.0...v2.2.0
[2.1.0]: https://github.com/Arvas65/sorbi/compare/v1.0.0...v2.1.0
[1.0.0]: https://github.com/Arvas65/sorbi/releases/tag/v1.0.0
